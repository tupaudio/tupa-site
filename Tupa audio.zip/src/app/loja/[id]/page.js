// src/app/loja/[id]/page.js
import { produtos } from '@/data/produtos';
import DetalheProdutoClient from './DetalheProdutoClient';

export default function ProdutoPage({ params }) {
  // Converte o ID para número de forma segura
  const id = parseInt(params.id);
  
  // Busca o produto
  const produto = produtos.find(p => p.id === id);
  
  // Se não encontrar, redireciona para a loja
  if (!produto) {
    // Usando redirect em vez de notFound para garantir
    return <div>Produto não encontrado. <a href="/loja">Voltar para loja</a></div>;
  }

  return <DetalheProdutoClient produto={produto} />;
}

// Metadados para SEO (opcional)
export async function generateMetadata({ params }) {
  const id = parseInt(params.id);
  const produto = produtos.find(p => p.id === id);
  
  if (!produto) {
    return { title: 'Produto não encontrado' };
  }

  return {
    title: produto.nome,
    description: produto.descricao,
  };
}